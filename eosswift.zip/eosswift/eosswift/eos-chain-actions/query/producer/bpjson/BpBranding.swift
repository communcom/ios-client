import Foundation

public struct BpBranding : Decodable {
    public let logo_256: String?
    public let logo_1024: String?
    public let logo_svg: String?
}
