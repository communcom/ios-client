import Foundation

public struct BpSocial : Decodable {
    public let steemit: String?
    public let twitter: String?
    public let youtube: String?
    public let facebook: String?
    public let github: String?
    public let reddit: String?
    public let telegram: String?
    public let wechat: String?
}
