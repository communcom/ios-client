import Foundation

public struct BlockProducer {
    public let bpJson: BpParent
    public let apiEndpoint: String
}
