@import Foundation;

//! Project version number for eos_swift.
FOUNDATION_EXPORT double eos_swiftVersionNumber;

//! Project version string for eos_swift.
FOUNDATION_EXPORT const unsigned char eos_swiftVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <eos_swift/PublicHeader.h>
