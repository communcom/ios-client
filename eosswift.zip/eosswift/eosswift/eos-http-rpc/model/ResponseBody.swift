import Foundation

public class ResponseBody : Decodable {
}
