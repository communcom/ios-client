import Foundation

public class RequestBody : Encodable {
}
